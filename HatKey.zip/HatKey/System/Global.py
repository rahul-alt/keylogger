import os

MAINPATH 	= os.path.abspath(os.path.join(os.path.dirname(__file__)))
VERSION 	= '1.0.0'
GITHUB		= 'https://github.com/enddo'
CODER		= 'Farzin Enddo'
AGENTS 		= list()
